<template>
  <div>

    <!-- 音乐播放 -->
    <div>
      <audio controls="controls">
        <source src="../assets/霸王龙.mp3" type="audio/mpeg" />
      </audio>
    </div>
    <!-- 图片显示 -->
    <div>
      <!-- <img src="../assets/logo.png"/> -->
      <img class="" src="https://img1.baidu.com/it/u=3059334288,1155981165&fm=26&fmt=auto" />
    </div>

    <!-- 获取后端数据 -->
    <div>
      <h1>{{ username }}</h1>
    </div>
    <div>
      <h1>{{ user.email }}</h1>
    </div>

    <!-- 按钮 -->
    <div class="btn">
      <input type="button" class="sign-in-button" value="测试按钮触发方法" @click="button_test()">
    </div>
    <div class="btn">
      <input type="button" class="sign-in-button" value="测试post方法提交String" @click="post_testString()">
    </div>
    <div class="btn">
      <input type="button" class="sign-in-button" value="测试post方法提交Object" @click="post_testObject()">
    </div>

    <!-- element-ui组件 -->
    <div class="block">
      <span class="demonstration">默认 click 触发子菜单</span>
      <el-cascader v-model="value" :options="options" @change="handleChange"></el-cascader>
    </div>
    <div class="block">
      <span class="demonstration">hover 触发子菜单</span>
      <el-cascader v-model="value" :options="options" :props="{ expandTrigger: 'hover' }" @change="handleChange">
      </el-cascader>
    </div>

  </div>
</template>

<script>
  import axios from 'axios'
  import qs from 'qs'
  export default {
    data() {
      return {
        username: '',
        user: {
          id: '',
          name: '',
          age: '',
          email: ''
        },
        /*测试post提交Object类型数据的辅助对象*/
        userTestPost: {
          id: '1',
          name: 'codeman',
          age: '21',
          email: '2635646017@qq.com'
        },
        value: [],
        options: [{
            value: "zhinan",
            label: "指南",
            children: [{
                value: "shejiyuanze",
                label: "设计原则",
                children: [{
                    value: "yizhi",
                    label: "一致",
                  },
                  {
                    value: "fankui",
                    label: "反馈",
                  },
                  {
                    value: "xiaolv",
                    label: "效率",
                  },
                  {
                    value: "kekong",
                    label: "可控",
                  },
                ],
              },
              {
                value: "daohang",
                label: "导航",
                children: [{
                    value: "cexiangdaohang",
                    label: "侧向导航",
                  },
                  {
                    value: "dingbudaohang",
                    label: "顶部导航",
                  },
                ],
              },
            ],
          },
          {
            value: "zujian",
            label: "组件",
            children: [{
                value: "basic",
                label: "Basic",
                children: [{
                    value: "layout",
                    label: "Layout 布局",
                  },
                  {
                    value: "color",
                    label: "Color 色彩",
                  },
                  {
                    value: "typography",
                    label: "Typography 字体",
                  },
                  {
                    value: "icon",
                    label: "Icon 图标",
                  },
                  {
                    value: "button",
                    label: "Button 按钮",
                  },
                ],
              },
              {
                value: "form",
                label: "Form",
                children: [{
                    value: "radio",
                    label: "Radio 单选框",
                  },
                  {
                    value: "checkbox",
                    label: "Checkbox 多选框",
                  },
                  {
                    value: "input",
                    label: "Input 输入框",
                  },
                  {
                    value: "input-number",
                    label: "InputNumber 计数器",
                  },
                  {
                    value: "select",
                    label: "Select 选择器",
                  },
                  {
                    value: "cascader",
                    label: "Cascader 级联选择器",
                  },
                  {
                    value: "switch",
                    label: "Switch 开关",
                  },
                  {
                    value: "slider",
                    label: "Slider 滑块",
                  },
                  {
                    value: "time-picker",
                    label: "TimePicker 时间选择器",
                  },
                  {
                    value: "date-picker",
                    label: "DatePicker 日期选择器",
                  },
                  {
                    value: "datetime-picker",
                    label: "DateTimePicker 日期时间选择器",
                  },
                  {
                    value: "upload",
                    label: "Upload 上传",
                  },
                  {
                    value: "rate",
                    label: "Rate 评分",
                  },
                  {
                    value: "form",
                    label: "Form 表单",
                  },
                ],
              },
              {
                value: "data",
                label: "Data",
                children: [{
                    value: "table",
                    label: "Table 表格",
                  },
                  {
                    value: "tag",
                    label: "Tag 标签",
                  },
                  {
                    value: "progress",
                    label: "Progress 进度条",
                  },
                  {
                    value: "tree",
                    label: "Tree 树形控件",
                  },
                  {
                    value: "pagination",
                    label: "Pagination 分页",
                  },
                  {
                    value: "badge",
                    label: "Badge 标记",
                  },
                ],
              },
              {
                value: "notice",
                label: "Notice",
                children: [{
                    value: "alert",
                    label: "Alert 警告",
                  },
                  {
                    value: "loading",
                    label: "Loading 加载",
                  },
                  {
                    value: "message",
                    label: "Message 消息提示",
                  },
                  {
                    value: "message-box",
                    label: "MessageBox 弹框",
                  },
                  {
                    value: "notification",
                    label: "Notification 通知",
                  },
                ],
              },
              {
                value: "navigation",
                label: "Navigation",
                children: [{
                    value: "menu",
                    label: "NavMenu 导航菜单",
                  },
                  {
                    value: "tabs",
                    label: "Tabs 标签页",
                  },
                  {
                    value: "breadcrumb",
                    label: "Breadcrumb 面包屑",
                  },
                  {
                    value: "dropdown",
                    label: "Dropdown 下拉菜单",
                  },
                  {
                    value: "steps",
                    label: "Steps 步骤条",
                  },
                ],
              },
              {
                value: "others",
                label: "Others",
                children: [{
                    value: "dialog",
                    label: "Dialog 对话框",
                  },
                  {
                    value: "tooltip",
                    label: "Tooltip 文字提示",
                  },
                  {
                    value: "popover",
                    label: "Popover 弹出框",
                  },
                  {
                    value: "card",
                    label: "Card 卡片",
                  },
                  {
                    value: "carousel",
                    label: "Carousel 走马灯",
                  },
                  {
                    value: "collapse",
                    label: "Collapse 折叠面板",
                  },
                ],
              },
            ],
          },
          {
            value: "ziyuan",
            label: "资源",
            children: [{
                value: "axure",
                label: "Axure Components",
              },
              {
                value: "sketch",
                label: "Sketch Templates",
              },
              {
                value: "jiaohu",
                label: "组件交互文档",
              },
            ],
          },
        ],
      };
    },
    /*测试get获取后端Object数据*/
    created() {
      const _this = this;
      axios.get('http://localhost:9090/get')
        .then(function (response) {
          _this.username = response.data.name
          _this.user = response.data
          console.log(_this.user)
        })
        .catch(function (error) {
          console.log(error);
        });
    },
    methods: {
      handleChange(value) {
        console.log(value);
      },
      button_test() {
        alert(this.user.name)
      },
      /*测试post提交String类型*/
      post_testString() {
        axios.post('http://localhost:9090/postString', {
            name: 'codeman'
          })
          .then(function (response) {
            console.log(response);
          })
          .catch(function (error) {
            console.log(error);
          });
      },
      /*测试post提交Object类型*/
      post_testObject() {
        this.$axios.post('http://localhost:9090/postObject',qs.parse(this.userTestPost))
          .then(function (response) {
            console.log(response);
          })
          .catch(function (error) {
            console.log(error);
          });
      }
    },
  };

</script>
